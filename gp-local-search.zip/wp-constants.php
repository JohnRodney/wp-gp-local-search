<?php

class WordPressCommands {
  public $adminMenu = 'admin_menu';
  public $adminInit = 'admin_init';
  public $queScripts = 'wp_enqueue_scripts';
}
