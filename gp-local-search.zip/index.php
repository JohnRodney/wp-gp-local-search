<?php
echo 'wordpress security procedures are top notch xD';
